package com.careers.deloitte;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentReports;

public class JobSearchHomePage extends ExtentReports {
	WebDriver driver;

	public JobSearchHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//*[@id='search-wrapper']/div/form/div/div[1]/div[1]/input")
	public WebElement searchText;

	@FindBy(xpath="//*[@id='header']/div[6]/div/div/div[3]/div/a")
	public WebElement mail;
	
	@FindBy(xpath="//*[@id='search-wrapper']/div/form/div/div[1]/div[3]/div[2]/div[1]/input")
	public WebElement searchJobsButton;

	@FindBy(xpath="//input[@id='location']")
	public WebElement location;

	@FindBy(xpath="(//div//button[@aria-label='Apply now'])[1]")
	public WebElement applyNow;

	@FindBy(xpath="//*[@id='username']")
	public WebElement emailAddress;

	@FindBy(xpath="//*[@id='password']")
	public WebElement password;

	@FindBy(xpath="//*[@id='page_content']/div[2]/div/div/div[2]/div/div/table/tbody/tr[3]/td[2]/span[1]/span/button")
	public WebElement SignIn;

	@FindBy(xpath="//strong[contains(text(),'Invalid username or password.  Please re-enter your login info.')]")
	public WebElement Error;

	@FindBy(xpath="//*[@id='cookie-accept']")
	public WebElement acceptAllCookies;


	public WebElement getSearchText() {
		return searchText;
	}
	public WebElement getSearchJobsButton() {
		return searchJobsButton;
	}
	public WebElement getLocation() {
		return location;
	}
	public WebElement getApplyNow() {
		return applyNow;
	}
	public WebElement getEmailAddress() {
		return emailAddress;
	}
	public WebElement getPassword() {
		return password;
	}
	public WebElement getSignIn() {
		return SignIn;
	}

	public WebElement getError() {
		return Error;
	}

	public void jobSearch() throws Exception
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
	//	driver.findElement(By.xpath("//*[@id='cookie-accept']")).click();
		acceptAllCookies.click();
		Thread.sleep(10000);
		Thread.sleep(500); 
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", mail);
		Thread.sleep(10000); 
		js.executeScript("window.scrollBy(0,350)", "");
		Thread.sleep(5000); 
		searchText.sendKeys("Automation Tester");
		Thread.sleep(3000);
		searchJobsButton.click();
		Thread.sleep(5000);
		location.sendKeys("Toronto");
		Thread.sleep(5000);
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='searchresults']/tbody/tr[1]/td[1]/span/a")).click();
		Thread.sleep(5000);

		driver.findElement(By.xpath("//*[@id='content']/div/div[3]/div/div[1]/div[1]/div/button")).click();
		List<WebElement> applynow = driver.findElements(By.xpath("//ul[@class='dropdown-menu socialbutton pull-right ']//li"));
		for(WebElement apply :applynow)
		{
			driver.findElement(By.xpath("//*[@id='applyOption-top-manual']")).click();
			break;
		}
		Thread.sleep(7000);
		emailAddress.sendKeys("test123@gmail.com");
		password.sendKeys("test123");
		SignIn.click();
		WebElement error=	driver.findElement(By.xpath("//*[@id='errorMsg_1']/strong"));
		if(error.getText().contains("Invalid username or password"))
		{
			screenshot();
			System.out.println("Error is validated"+"Login failed with Unvalid data"+error.getText());

		}
		else {
			screenshot();
			System.out.println("Error is not displayed"+"Logged In Successfully.");

		}


	}	
	public void screenshot() throws IOException
	{
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(scrFile, new File("src\\main\\resources\\screenshots\\failedScreenshot.png"));
		} catch (IOException e) {
			FileUtils.copyFile(scrFile, new File("src\\main\\resources\\screenshots\\PassedScreenshot.png"));
			e.printStackTrace();
		}
	}
}