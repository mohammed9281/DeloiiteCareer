package com.stepDefinition;

import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.careers.deloitte.JobSearchHomePage;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.observer.ExtentObserver;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;


public class CareerJobSearch extends ExtentReports{
	
 ExtentHtmlReporter htmlReporter;
 ExtentTest test;
 WebDriver driver;
 
 @BeforeTest
 	public void startTest() {
	 	ExtentReports     reports = new ExtentReports();
	 	htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "//test-output//Extentreport.html");

         reports.setSystemInfo("Machine", "");
         reports.setSystemInfo("Env", "");
         reports.setSystemInfo("Build", "Integration");
         reports.setSystemInfo("Browser", "CHROME");

 }
	 @BeforeMethod
	  public void beforeMethod() {
		 WebDriverManager.chromedriver().setup();
		 
	 }


		  


	@Test
  public void careerJobSearch() throws Exception {
		try {
        driver = new ChromeDriver();
        driver.get("https://careers.deloitte.ca/");
		 driver.manage().window().maximize();
    	JobSearchHomePage homepage = new JobSearchHomePage(driver);
    	homepage.jobSearch();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
  }
 
  @AfterMethod
  public void afterMethod() {
	  driver.close();
  }

}
