package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.careers.deloitte.AmazonHomePage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonLogin {
 WebDriver driver;
	 @BeforeMethod
	  public void beforeMethod() {
		 WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();

		  
	  }

	@Test
  public void amazonErrorLogin() {
		try {
          driver.get("https://www.amazon.ca/");
		  driver.manage().window().maximize();
    		AmazonHomePage homepage = new AmazonHomePage(driver);
    		homepage.amazonProductList();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
  }
 
  @AfterMethod
  public void afterMethod() {
	  driver.close();
  }
}