package com.careers.deloitte;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AmazonHomePage {
	WebDriver driver;

	public AmazonHomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//input[@value='Proceed to checkout']")
	public WebElement proceedToCheckOut;

	@FindBy(xpath="//input[@title='Add to Shopping Cart']")
	public WebElement addToCart;

	@FindBy(xpath="//input[@name='email']")
	public WebElement emailAddress;

	@FindBy(xpath="//input[@name='password']")
	public WebElement password;

	@FindBy(xpath="//input[@type='submit']")
	public WebElement signIn;

	@FindBy(xpath="//div[@id='auth-error-message-box']//li/span")
	public WebElement Error;

	@FindBy(xpath="//input[@aria-labelledby='continue-announce']")
	public WebElement continueBtn;


	public void amazonProductList() throws Exception
	{		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='nav-hamburger-menu']")).click();
		Thread.sleep(5000);
		List<WebElement> allDropDown = driver.findElements(By.xpath("//*[@id='hmenu-content']/ul[@class='hmenu hmenu-visible']/li/a"));
		for(WebElement dropDown :allDropDown )
		{
			System.out.println(dropDown.getText());
			if(dropDown.getText().contains("New Releases"))
			{
				dropDown.click();
				break;
			}
		}
		Thread.sleep(5000);

		List<WebElement> products = driver.findElements(By.xpath("//ol[@class='a-carousel']/li//a"));
		for(WebElement productsList :products )
		{
			System.out.println(productsList.getText());
			if(productsList.getText().contains("Electronic Return Box for Sale"))
			{
				productsList.click();
				break;
			}
		}

		Thread.sleep(5000);

		WebElement addToCart = driver.findElement(By.xpath("//input[@title='Add to Shopping Cart']"));
		addToCart.click();
		Thread.sleep(5000);

		proceedToCheckOut.click();
		emailAddress.sendKeys("test123@gmail.com");
		Thread.sleep(3000);
		continueBtn.click();
		Thread.sleep(3000);
		password.sendKeys("test123");
		Thread.sleep(3000);
		signIn.click();
		Thread.sleep(7000);
		
		if(Error.getText().contains("Your password is incorrect"))
		{
			screenshot();
			System.out.println("Password Entered is not Correct"+Error.getText());
		}
		else
		{
			System.out.println("Logged In Successfully");
		}
	}

	public void screenshot() throws IOException
	{
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(scrFile, new File("src\\main\\resources\\screenshots\\PassedScreenshot.png"));
		} catch (IOException e) {
			FileUtils.copyFile(scrFile, new File("src\\main\\resources\\screenshots\\failedScreenshot.png"));
			e.printStackTrace();
		}
	}
}